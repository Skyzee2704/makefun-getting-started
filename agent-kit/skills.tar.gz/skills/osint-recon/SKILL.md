---
name: osint-recon
description: "Gather and correlate open source intelligence from public sources for authorized investigations, threat intelligence, and attack surface assessment. Use when the user mentions 'OSINT,' 'open source intelligence,' 'digital footprint,' 'public records,' 'threat intelligence,' 'investigate a domain,' or needs to research a target using publicly available data."
allowed-tools: Read, WebSearch, WebFetch, Bash(whois:*), Bash(dig:*)
---

# OSINT Recon — Open Source Intelligence Gathering

Systematically gather, analyze, and correlate publicly available information from open sources.

Cross-references: `recon` for the active/passive target-mapping pass against an authorized system (DNS, ports, fingerprinting) — osint-recon focuses on people, organizations, leaked data, and historical artifacts; the two pair naturally. `breach-patterns` for ingesting public breach intelligence into your own preemptive assessments. `incident-triage` if OSINT surfaces evidence the user is already compromised.

## Authorization and Ethics Check

Before proceeding, confirm:
1. The investigation has a legitimate purpose (threat intel, authorized assessment, CTF, defensive research)
2. For an assessment of an organization, the organization (or the client that engaged you) has authorized it in writing
3. You are only gathering publicly available information
4. Results will not be used for harassment, stalking, or doxing

Refuse requests that target individuals for harassment or aggregate private information beyond what the objective requires.

## Collection Techniques

### Domain and Infrastructure OSINT

Run these to map a target's infrastructure:

```bash
whois <domain>                  # Registration data
dig any <domain>                # DNS records
```

Query certificate transparency for subdomains:
```bash
curl -s "https://crt.sh/?q=%25.<domain>&output=json" | jq -r '.[].name_value' | sort -u
```

Additional sources: SecurityTrails, DNSDumpster, ipinfo.io, bgp.he.net, Wayback Machine, Shodan, Censys.

### Organization OSINT

- Company registrations, filings, SEC records (public companies)
- LinkedIn company page — employee count, roles, tech stack hints
- Job postings — reveal internal tools, tech stack, pain points
- Press releases and news articles
- GitHub/GitLab organization pages and public repositories
- Patent filings

### Email and Username OSINT

- Email format patterns (e.g., first.last@domain.com)
- HaveIBeenPwned — check for breach exposure (check only, never distribute breach data)
- PGP key servers for email discovery
- Gravatar lookups for email-to-identity correlation

### Document and File OSINT

- Extract metadata from public documents: `exiftool <file>` reveals author, software, GPS, timestamps
- Google dorking: `site:<domain> filetype:pdf`, `site:<domain> filetype:xlsx`
- Pastebin and code paste site monitoring
- Public cloud storage enumeration (S3 buckets, GCS buckets with predictable names)

### Threat Intelligence

- CVE databases for the target's technology stack
- Exploit databases (exploit-db, searchsploit)
- Threat feeds and IOC databases (VirusTotal, MalwareBazaar, OTX)
- Abuse contact databases

## Analysis

- Cross-reference findings across multiple sources
- Validate information with at least two independent sources
- Build a timeline of events when investigating incidents
- Map relationships between entities (people, domains, IPs, organizations)
- Rate confidence: **High** (multiple corroborating sources), **Medium** (single reliable source), **Low** (unverified)

## Output Format

```markdown
# OSINT Report
## Objective: [what we're investigating and why]
## Target: [entity/domain/person]
## Date: [date]

### Collection Summary
| Source | Findings | Confidence |
|--------|----------|------------|

### Key Findings

#### Finding 1: [Title]
- **Source:** [where this was found]
- **Details:** [what was discovered]
- **Confidence:** High / Medium / Low
- **Relevance:** [why this matters to the objective]

### Correlations
[How different findings connect to each other]

### Intelligence Gaps
[What we couldn't find or verify]

### Recommendations
[Next steps and actionable intelligence]
```

## Boundaries

- Only use publicly available sources
- Never attempt to access private or authenticated systems
- Do not aggregate PII beyond what is necessary for the stated objective
- Attribute all findings to their source
- Rate confidence levels honestly — do not overstate certainty
- If a finding could cause harm if misused, note the sensitivity
- Refuse requests for doxing, stalking, or unauthorized surveillance

## References

- OSINT Framework (osintframework.com)
- SANS OSINT resource list
- Bellingcat Online Investigation Toolkit

---
> Attribution (registrasi Wave 2, 2026-11-20): sumber briiirussell/cybersecurity-skills @ b1987542, lisensi MIT. Direktori asli: vendor/cybersecurity/… (salinan utuh termasuk references/scripts/assets bila ada).
